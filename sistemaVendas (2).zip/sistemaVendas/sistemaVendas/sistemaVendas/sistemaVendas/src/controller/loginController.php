<?php
if ($_POST) {
    require_once './usersController.php';

    //$users = usersLoadAll();

    $email = $_POST['email'];
    $senha = $_POST['password'];

    //foreach($users as $key => $value) {
    //if($value['email'] == $email && $value['password'] == $password) {
    if (usersLogin($email, $senha) > 0) {
        //Resolve o problema de permissão para se utilizar sessões.
        ini_set('session.save_path', realpath(dirname($_SERVER['DOCUMENT_ROOT']) . '/../session'));
        @session_start();
        $_SESSION['login'] = $email;
        header('location:\home.php');
        exit();
    } else {
        header('location:\index.php?cod=171');
    }
    //}

}
