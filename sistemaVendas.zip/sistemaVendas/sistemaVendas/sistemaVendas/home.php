<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>    
    <link rel="stylesheet" type="text/css" href="../src/style/homestyle.css">
</head>
<body>
    <h1>Loja Musical</h1>

    <div class="container">
                <form method="post" action="./src/controller/pedidosController.php">
                <?php
                    require_once 'src/controller/authenticationController.php';
                    require_once 'src/controller/itensController.php';

                    $itens = itensLoadAll();
                
                    foreach($itens as $key => $value) {
                        echo '<input type="checkbox" value="'.$value['id'].'" name="itens[]">';
                        echo ' '. $value['nome'];
                        echo '<input style="margin-left: 10px; width: 50px;" type="number" value="0" min="0" max="'.$value['estoque'].'" name="quantidade[]">';
                        echo '<br>';
                    }

                   
                    
                    echo '<input type="submit" value="Realizar pedido">';
                    
                    
                    if (isset($_GET['cod']) && $_GET['cod'] === 'error') {
                        echo '<p style="color: red;">Quantidade e/ou pedido inválido!</p>';
                    }
                    if (isset($_GET['cod']) && $_GET['cod'] === 'success') {
                        echo '<p style="color: green;">Pedido realizado com sucesso!</p>';
                    }

                   
                    
                ?>
                

                
                </form>

                <a href="../pedidos.php" class="btn btn-danger">Vizualizar pedidos</a>
            </div>
</body>
</html>