<?php
    require_once __DIR__ .'/../model/conexaoMySQL.php';
    function usersLogin($email,$senha){
        $db = new ConexaoMysql();
        $db->Conectar();
        $sql = 'SELECT * FROM usuarios WHERE email="'.$email.'" AND senha="'.$senha.'" limit 1';
        $result =$db->Consultar($sql);
        $db->Desconectar();
        return $db->total; //retorna o número de registros selecionados pela consulta sql.
    }
    function usersLoadAll(){
        $db = new ConexaoMysql();

        $db->Conectar();  

        $sql = 'SELECT * FROM usuarios';

        $result = $db->Consultar($sql);

        $db->Desconectar();

        return $result;
    }

?>