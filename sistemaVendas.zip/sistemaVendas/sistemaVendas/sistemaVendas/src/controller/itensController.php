<?php
include_once __DIR__ . '/../model/conexaoMySQL.php';

function itensLoadAll()
{
   
    $con = new conexaoMySQL(); 

    $con->Conectar();

  
    $sql = 'SELECT * FROM itens';
   
    $result = $con->Consultar($sql);

  
    $con->Desconectar();

    return $result;
}
