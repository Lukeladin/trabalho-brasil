<?php
    if($_POST){
        
        require_once './usersController.php';

        $email = $_POST['email'];
        $senha = $_POST['password'];


        if(usersLogin($email, $senha) > 0){
            ini_set('session.save_path', realpath(dirname($_SERVER['DOCUMENT_ROOT']) . '/../session'));
            //dizendo onde os arquivos de sessão devem ser salvos.
            $usuario = usersLogin($email,$senha);
            $tipoUsuario = $usuario[5];
            
            var_dump($usuario);
            

            @session_start();


            $_SESSION['tipoUsuario'] = $tipoUsuario;
            $_SESSION['login'] = $email;
            // header('location:\home.php');
            
            exit();

           
        }
        else{
            header('location:\index.php?cod=112');
        }

    }
