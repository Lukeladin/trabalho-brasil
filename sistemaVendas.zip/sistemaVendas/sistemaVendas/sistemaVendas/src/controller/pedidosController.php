<?php
include_once __DIR__ . '/../model/ConexaoMySQL.php';

if ($_POST) {
    $itens = isset($_POST['itens']) ? $_POST['itens'] : null;
    $quantidade = $_POST['quantidade'];
   
    foreach ($quantidade as $key => $value) {
        if($value == null) $value = 0;
    }

    if (array_sum($quantidade )> 0 && $itens != null) {
        print_r($itens);
        print_r($quantidade);
        $con = new ConexaoMysql();
        $con->Conectar();
        $totalItens = array_sum($quantidade);
        ini_set('session.save_path', realpath(dirname($_SERVER['DOCUMENT_ROOT']) . '/../session'));
        session_start();
        $sqlUsuario = 'select id from usuarios where email="' . $_SESSION['login'] . '" limit 1';
        $resultUsuario = $con->Consultar($sqlUsuario);
        foreach ($resultUsuario as $key => $value) {
            $idUsuario = $value['id'];
        }
        $sqlPedidos = 'INSERT INTO pedidos(data_compra,usuario_id) VALUES(now(),'.$idUsuario.')';
        
        
        $lastInsertId = $con->Executar($sqlPedidos);
        echo $lastInsertId;
        foreach ($itens as $key => $value) {
            $sqlItensPedido = 'INSERT INTO pedidos_itens values (0,' . $lastInsertId . ',' . $value . ',' . $quantidade[$key] . ', 10)';
            echo $sqlItensPedido;
            $con->Executar($sqlItensPedido);
        }
        pedidosUpdate(0,$totalItens,$idUsuario);

        $con->Desconectar();
        header('location:\home.php?cod=success');
    } else {
        header('location:\home.php?cod=error');
    }
}
else if ($_REQUEST && isset($_REQUEST['cmd']) && $_REQUEST['cmd'] == 'del') {
    $id = $_REQUEST['id'];
    $total = pedidosDelete($id);
    if ($total > 0) {
        header('location:\home.php?cod=success');
    } else {
        header('location:\pedidos.php?cod=error');
    }
}


function pedidosDelete($id)
{
    $con = new ConexaoMysql();
    $con->Conectar();

    $sqlPedidosItens = 'DELETE FROM pedidos_itens WHERE pedido_id=' . $id;

    var_dump($sqlPedidosItens);
    $con->Executar($sqlPedidosItens);
    $sqlPedidos =  'DELETE FROM pedidos WHERE id=' . $id;
    $con->Executar($sqlPedidos);
    $total = $con->total;

    $con->Desconectar();
    return   $total;
}

function pedidosUpdate($id, $valor_total, $usuario_id)
{
    $con = new ConexaoMysql();
    $con->Conectar();
    $sql = 'UPDATE pedidos SET "valor_total="' . $valor_total . '",usuario_id="' . $usuario_id . '" WHERE id=' . $id;
    echo $sql;
    $con->Executar($sql);
    $total = $con->total;
    $con->Desconectar();
    return   $total;
}

function projectsInsert($nome, $status)
{
    $con = new ConexaoMysql(); 
    $con->Conectar();
    $sql = 'INSERT INTO projetos VALUES (0,"' . $nome . '","' . $status . '")';
    echo $sql;
    $con->Executar($sql);
    $id = $con->total; 
    $con->Desconectar();
    return   $id;
}

function projectsLoadById($id)
{
    $con = new ConexaoMysql();
    $con->Conectar();
    $sql = 'SELECT * FROM projetos WHERE id=' . $id;
    $result = $con->Consultar($sql);
    $result = mysqli_fetch_array($result);
    $con->Desconectar();
    return $result;
}

function pedidosLoadAll()
{
    $con = new ConexaoMysql(); 
    $con->Conectar();
    $sql = 'SELECT * FROM pedidos';
    $result = $con->Consultar($sql);
    $con->Desconectar();
    return $result;
}