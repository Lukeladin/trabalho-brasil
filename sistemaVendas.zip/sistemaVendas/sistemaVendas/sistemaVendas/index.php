<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Virtuose</title>
    <link rel="stylesheet" type="text/css" href="../src/style/style.css">
</head>
<body>
    <h1>Bem vindo à Loja!</h1>
    <div class="container">
    <form action="/src/controller/loginController.php" method="post" class="col-md-8 col-6 bg-light p-3 border rounded-3">
                
                    <label>Email:</label>
                    <input type="email" name="email" id="email" placeholder="Insira seu email aqui">
                    <br><br>
                    <label>Senha:</label>
                    <input type="password" name="password" id="password" placeholder="Insira sua senha aqui">
                    <br><br>   
                    <input type="submit" value="Entrar">
      
            </form>
            
            <?php
                require_once 'src/controller/usersController.php';

                $users = usersLoadAll();
                
                echo '<table class="table">';
                echo '<tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Senha</th>
                </tr>';

            

                foreach($users as $key => $value) {
                    echo '<tr>';
                        echo '<th>'.$value['id'].'</th>';
                        echo '<td>'.$value['nome'].'</td>';
                        echo '<td>'.$value['email'].'</td>';
                        echo '<td>'.$value['senha'].'</td>';
                    echo '</tr>';
                }
                echo '</table>';

                if (isset($_GET['cod']) && $_GET['cod'] === '112') {
                    echo '<p style="color: red;">Email e/ou senha incorreto!</p>';
                }
            ?>
</div>
</body>
</html>