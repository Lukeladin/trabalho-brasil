<?php
include_once __DIR__ . '/../model/ConexaoMySQL.php';

if ($_POST) {
    $itens = $_POST['itens'];
    var_dump($_POST['quantidade']);
    print(array_sum($_POST['quantidade']));
   
    if (array_sum($_POST['quantidade'])> 0) {
        $quantidade = $_POST['quantidade'];
        print_r($itens);
        print_r($quantidade);
        $con = new ConexaoMysql();
        $con->Conectar();
        $totalItens = array_sum($quantidade);
        ini_set('session.save_path', realpath(dirname($_SERVER['DOCUMENT_ROOT']) . '/../session'));
        session_start();
        $sqlUsuario = 'select id from usuarios where email="' . $_SESSION['login'] . '" limit 1';
        $resultUsuario = $con->Consultar($sqlUsuario);
        foreach ($resultUsuario as $key => $value) {
            $idUsuario = $value['id'];
        }
        $sqlPedidos = 'INSERT INTO pedidos VALUES(0,NOW(),' . $totalItens . ',' . $idUsuario . ')';
        $lastInsertId = $con->Executar($sqlPedidos);
        foreach ($itens as $key => $value) {
            $sqlItensPedido = 'INSERT INTO pedidos_itens values (0,' . $quantidade[$key] . ', 10, ' . $lastInsertId . ',' . $value . ')';
            $con->Executar($sqlItensPedido);
        }
        $con->Desconectar();
        header('location:\pedidos.php?cod=success');
    } else {
       
    }
}
else if ($_REQUEST && isset($_REQUEST['cmd']) && $_REQUEST['cmd'] == 'del') {
    $id = $_REQUEST['id'];
    $total = pedidosDelete($id);
    if ($total > 0) {
        header('location:\pedidos.php?cod=success');
    } else {
        header('location:\pedidos.php?cod=error');
    }
}


function pedidosDelete($id)
{
    $con = new ConexaoMysql();
    $con->Conectar();
    $sqlPedidosItens = 'DELETE FROM pedidos_itens WHERE pedidos_id=' . $id;
    $con->Executar($sqlPedidosItens);
    $sqlPedidos =  'DELETE FROM pedidos WHERE id=' . $id;
    $con->Executar($sqlPedidos);
    $total = $con->total;
    $con->Desconectar();
    return   $total;
}

function projectsUpdate($id, $nome, $status)
{
    $con = new ConexaoMysql();
    $con->Conectar();
    $sql = 'UPDATE projetos SET nome="' . $nome . '",status="' . $status . '" WHERE id=' . $id;
    echo $sql;
    $con->Executar($sql);
    $total = $con->total;
    $con->Desconectar();
    return   $total;
}

function projectsInsert($nome, $status)
{
    $con = new ConexaoMysql(); 
    $con->Conectar();
    $sql = 'INSERT INTO projetos VALUES (0,"' . $nome . '","' . $status . '")';
    echo $sql;
    $con->Executar($sql);
    $id = $con->total; 
    $con->Desconectar();
    return   $id;
}

function projectsLoadById($id)
{
    $con = new ConexaoMysql();
    $con->Conectar();
    $sql = 'SELECT * FROM projetos WHERE id=' . $id;
    $result = $con->Consultar($sql);
    $result = mysqli_fetch_array($result);
    $con->Desconectar();
    return $result;
}

function pedidosLoadAll()
{
    $con = new ConexaoMysql(); 
    $con->Conectar();
    $sql = 'SELECT * FROM pedidos';
    $result = $con->Consultar($sql);
    $con->Desconectar();
    return $result;
}