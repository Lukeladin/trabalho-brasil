<?php
     //Resolve o problema de permissão para se utilizar sessões.
     ini_set('session.save_path',realpath(dirname($_SERVER['DOCUMENT_ROOT']) . '/../session'));
           
    @session_start();
    if(!isset($_SESSION['login'])) {
        header('location:\index.php?cod=405');
        exit();
    }
?>