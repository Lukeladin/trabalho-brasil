<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>    
    <link rel="stylesheet" type="text/css" href="../src/style/homestyle.css">
</head>
<body>
    <h1>Virtuose</h1>

    <div>
                <form method="post" action="./src/controller/pedidosController.php">
                <?php
                    require_once 'src/controller/authenticationController.php';
                    require_once 'src/controller/itensController.php';

                    $itens = itensLoadAll();
                
                    foreach($itens as $key => $value) {
                        echo '<input type="checkbox" value="'.$value['id'].'" name="itens[]">';
                        echo ' '. $value['nome'];
                        echo '<input style="margin-left: 10px; width: 50px;" type="number" value="0" min="0" max="'.$value['estoque'].'" name="quantidade[]">';
                        echo '<br>';
                    }
                    
                ?>
                <input type="submit" value="Realizar pedido">
                </form>
            </div>
</body>
</html>