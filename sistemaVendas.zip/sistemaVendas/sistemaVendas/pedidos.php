<!doctype html>
<html lang="en">
    <head>
        <title>Pedidos</title>
        <meta charset="utf-8" />
        <meta
            name="viewport"
            content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
            <link rel="stylesheet" href="/src/style/bootstrap.min.css">
            <link rel="stylesheet" href="/src/style/style.css">
            <script src="/src/script/bootstrap.bundle.min.js"></script>
    </head>
    <body>
        <main>
            <a href="\src/controller/logoutController.php" class="btn btn-danger">Logout</a>
            <a href="home.php">Realizar Pedido</a>
            <h1>Pedidos</h1>
            <div>
                <?php
                require_once 'src/controller/authenticationController.php';
                require_once 'src/controller/pedidosController.php';
                $pedidos = pedidosLoadAll();
                    
                    echo '<table class="table col-md-6 col-8">';
                    echo '<tr>
                        <th>ID</th>
                        <th>Data da compra </th>
                        <th>Quantidade</th>
                        <th>Operações</th>
                    </tr>';
                    foreach($pedidos as $key => $value) {
                        echo '<tr>';
                            echo '<th>#'.$value['id'].'</th>';
                            echo '<th>'.$value['data_compra'].'</th>';
                            echo '<td>'.$value['valor_total'].'</td>';
                            echo '<td>
                                    <a href="/src/controller/pedidosController.php?cmd=del&&id='.$value['id'].'">Excluir</a>
                                  </td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                ?>
            </div>
        </main>
    </body>
</html>